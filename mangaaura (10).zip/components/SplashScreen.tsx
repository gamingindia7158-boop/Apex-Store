
import React from 'react';
import { motion } from 'framer-motion';

const SplashScreen: React.FC = () => {
  const panels = [
    'https://images.unsplash.com/photo-1614728263952-84ea256f9679?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1605806616949-1e87b487fc2f?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800',
    'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?auto=format&fit=crop&q=80&w=800'
  ];

  return (
    <motion.div 
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-[#050505] overflow-hidden"
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 1.2, ease: "easeInOut" }}
    >
      {/* Dynamic Background Grid */}
      <div className="absolute inset-0 grid grid-cols-2 gap-4 opacity-30 -rotate-12 scale-125">
        {panels.map((src, i) => (
          <motion.div
            key={i}
            initial={{ scale: 1.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 3, delay: i * 0.3, ease: "easeOut" }}
            className="w-full h-full bg-cover bg-center rounded-[40px] border border-white/10"
            style={{ backgroundImage: `url(${src})` }}
          />
        ))}
      </div>

      {/* Vignette Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black opacity-80" />

      {/* Centered Logo */}
      <div className="relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          <motion.h1 
            initial={{ letterSpacing: '1em' }}
            animate={{ letterSpacing: '0.3em' }}
            transition={{ duration: 2, ease: "easeOut" }}
            className="text-7xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-blue-500 to-cyan-400 neon-glow"
          >
            MANGAAURA
          </motion.h1>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: "100%" }}
            transition={{ delay: 1.5, duration: 1.5 }}
            className="h-[1px] bg-gradient-to-r from-transparent via-blue-500 to-transparent mt-4 shadow-[0_0_15px_rgba(59,130,246,0.8)]"
          />
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ delay: 2, duration: 1 }}
            className="mt-6 text-gray-400 uppercase tracking-[0.6em] text-[10px] font-black"
          >
            Emotional Reading Redefined
          </motion.p>
        </motion.div>
      </div>

      {/* Bottom Loading Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.5 }}
        className="absolute bottom-20 flex flex-col items-center gap-4"
      >
        <div className="flex gap-2">
          {[0, 1, 2].map(i => (
            <motion.div 
              key={i}
              animate={{ y: [0, -10, 0], opacity: [0.3, 1, 0.3] }}
              transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.2 }}
              className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_#3b82f6]"
            />
          ))}
        </div>
        <span className="text-[9px] font-black text-gray-600 tracking-widest uppercase">Initializing Aura</span>
      </motion.div>
    </motion.div>
  );
};

export default SplashScreen;
