
import { useCallback, useRef } from 'react';
import { SFX_URLS } from '../constants';

export const useSound = (enabled: boolean = true) => {
  const audioRefs = useRef<{ [key: string]: HTMLAudioElement }>({});

  const playSound = useCallback((type: keyof typeof SFX_URLS) => {
    if (!enabled) return;
    
    if (!audioRefs.current[type]) {
      audioRefs.current[type] = new Audio(SFX_URLS[type]);
    }
    const audio = audioRefs.current[type];
    audio.currentTime = 0;
    audio.volume = 0.4;
    audio.play().catch(() => {});
  }, [enabled]);

  return { playSound };
};
