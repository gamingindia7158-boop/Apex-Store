
import { Manga, User, Language } from './types';

export const DEMO_MANGA: Manga = {
  id: 'demo-1',
  title: 'Neon Blade',
  author: 'MangaAura Original',
  cover: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?auto=format&fit=crop&q=80&w=800',
  description: 'In the heart of Neon City, a lone warrior battles the shadows of the future.',
  tags: ['Action', 'Cyberpunk', 'Original'],
  trending: true,
  isPremium: false,
  chapters: [
    {
      id: 1,
      title: 'Chapter 1: The Awakening',
      pages: [
        'https://images.unsplash.com/photo-1614728263952-84ea256f9679?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1605806616949-1e87b487fc2f?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1542332213-31f87348057f?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=800',
        'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=800'
      ],
      dialogues: [
        { panelIndex: 0, speaker: 'Narrator', text: 'Neon City… ek sheher jo kabhi sota nahi.', emotion: 'Epic' },
        { panelIndex: 1, speaker: 'Hero', text: 'Is sheher ki roshni ke peeche andhera chhupa hai…', emotion: 'Sad' },
        { panelIndex: 2, speaker: 'Shadow', text: 'Tumhe lagta hai tum akela ho?', emotion: 'Angry' },
        { panelIndex: 3, speaker: 'Hero', text: 'Kaun ho tum?', emotion: 'Epic' },
        { panelIndex: 4, speaker: 'Villain', text: 'Main tumhara kal hoon…', emotion: 'Angry' },
        { panelIndex: 5, speaker: 'Hero', text: 'Toh aaj hi faisla ho jaaye.', emotion: 'Epic' },
        { panelIndex: 6, speaker: 'Narrator', text: 'SHIIING!', emotion: 'Epic' },
        { panelIndex: 7, speaker: 'Narrator', text: 'To be continued…', emotion: 'Epic' }
      ]
    }
  ]
};

export const MOCK_MANGAS: Manga[] = [
  DEMO_MANGA,
  {
    id: '1',
    title: 'Void Walker',
    author: 'Sora Kaminari',
    cover: 'https://images.unsplash.com/photo-1578632738980-23055589ee99?auto=format&fit=crop&q=80&w=800',
    description: 'In a world where light is a currency, one boy walks the darkness.',
    tags: ['Action', 'Mystery', 'Sci-Fi'],
    trending: true,
    isPremium: false,
    chapters: Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      title: `Chapter ${i + 1}`,
      pages: Array.from({ length: 5 }, (_, p) => `https://picsum.photos/seed/void${i}${p}/800/1200`)
    }))
  },
  {
    id: '2',
    title: 'Neon Ronin',
    author: 'Takeshi Neo',
    cover: 'https://images.unsplash.com/photo-1541562232579-512a21360020?auto=format&fit=crop&q=80&w=800',
    description: 'Cybernetic samurai battles in the megacities of tomorrow.',
    tags: ['Cyberpunk', 'Action', 'Samurai'],
    trending: true,
    isPremium: true,
    chapters: Array.from({ length: 5 }, (_, i) => ({
      id: i + 1,
      title: `Chapter ${i + 1}`,
      pages: Array.from({ length: 5 }, (_, p) => `https://picsum.photos/seed/ronin${i}${p}/800/1200`)
    }))
  }
];

export const MOCK_USER: User = {
  id: 'user_1',
  name: 'Zenith',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
  coins: 450,
  streak: 7,
  favorites: ['demo-1', '2'],
  readChapters: 15,
  soundEnabled: true
};

export const LANGUAGES: Language[] = [
  'Hindi', 'Japanese', 'English', 'Bengali', 'Korean', 'Spanish', 'French', 'Arabic', 'Tamil'
];

export const SFX_URLS = {
  CLICK: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
  WHOOSH: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
  CHIME: 'https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3',
  PAGE: 'https://assets.mixkit.co/active_storage/sfx/612/612-preview.mp3',
  REWARD: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
  SPARKLE: 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3'
};
